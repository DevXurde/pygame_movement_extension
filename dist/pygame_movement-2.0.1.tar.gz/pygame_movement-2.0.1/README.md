# pygame_movement_extension
This is a Pygame extension to exhibit movement with few lines of code.
